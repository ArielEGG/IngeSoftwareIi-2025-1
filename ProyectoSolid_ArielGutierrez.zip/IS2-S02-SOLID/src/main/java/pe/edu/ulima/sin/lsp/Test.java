package pe.edu.ulima.sin.lsp;

public class Test {
    public static void main(String[] args) {
        Ave a1 = new Pato();
        a1.volar();
        
        Ave a2 = new Pinguino();
        a2.volar();
    }
}
