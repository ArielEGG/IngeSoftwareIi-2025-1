package pe.edu.ulima.sin.isp;

public interface Animal {
    public void comer();
    public void volar();
    public void nadar();
}