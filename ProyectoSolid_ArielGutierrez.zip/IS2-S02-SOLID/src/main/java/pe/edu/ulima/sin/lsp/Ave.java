package pe.edu.ulima.sin.lsp;

public class Ave {

    public void volar() {
        System.out.println("Ave volando ...");
    }
}
