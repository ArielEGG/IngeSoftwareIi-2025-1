package solucion.ocp;

import pe.edu.ulima.sin.ocp.*;
import java.util.List;

public class Area {
    public double calcularArea(Figura f) {
        return f.calcularArea();
    }
}