package solucion.ocp;


public interface Figura {

    double calcularArea();
}
